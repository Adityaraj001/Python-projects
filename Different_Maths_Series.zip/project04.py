#!/usr/bin/env python
# coding: utf-8

# In[3]:


'''

Adityaraj jain

jainaditya12341@gmail.com

homework 04

'''


x="0"
while x>="0":
    
#Asking user for the option mentioned
        option= input("Pick an option:\n1) Fibonacci sequence\n2) Factorial sequence\n3) Approximations of pi\n4) Approximations of e\n?) Quit\n")
        if option=="1" or option=="2" or option=="3" or option=="4":
            items= int(input("How many items (2 or more please):"))
            while items< 2:
                items= int(input("How many items (2 or more please):"))
                
#Generating fibonacci sequence     
            if option == "1":
                a=0
                b=1
                fibo = [a,b]
                for i in range(1,items):
                    c= fibo[i] + fibo[i-1]
                    fibo.append(c)
                print("\n"+str(fibo)+"\n")
                
#Generating factorial sequence
            elif option == "2":
                n=1
                fact = [1]
                for i in range(1,items+1):
                    n=n*i
                    fact.append(n)
                print("\n"+str(fact)+"\n")
                
#Generating Approximations of pi        
            elif option == "3":
                add=0
                pi=[]
                for i in range(0,items+1):
                    a=(-1)**i
                    b= (2*i) +1
                    c=a/b
                    pi.append(c)
                    add = add + pi[i]
                print("\n"+str(add*4)+"\n")

#Generating Approximations of e
            else:
                import math
                n=1
                add=0
                approx_e=[]
                for i in range(0,items+1):
                    b=1**i
                    n=math.factorial(i)
                    c=b/n
                    approx_e.append(c)
                    add = add + approx_e[i]
                print("\n"+str(add)+"\n")

#Exit
        else:
            print("Goodbye!")
            break
        

        
        
        


# In[ ]:





# In[ ]:




