#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#Adityaraj jain
#jainaditya12341@gmail.com

#Part 1:Calculating Down Payment

print("Bank of Nathan – Auto Loan Payment Calculator")
new_vehicle_price = float(input("Enter the vehicle's purchase price: "))
down_payment = float(input("Enter the down payment for the vehicle: "))
salestax = float(input("Enter the sales tax on the transaction (for 8.25% tax, enter 8.25): "))
trade= input("Do you have a vehicle to trade in? (y/n): ")

if trade.lower() == "y" :
    tradeIn=float(input("Enter the trade-in value of your current vehicle: "))
    amounttrade=float(input("Enter the amount owed on your current vehicle: "))
else:
    tradeIn =0
    amounttrade=0

    
total_dpayment = float(down_payment +(tradeIn - amounttrade))
print("Your overall down payment is $" + str(total_dpayment) )

loan_Amount =float ((new_vehicle_price-total_dpayment)*(1 + (salestax/100)))
print("Your overall loan amount is $" + str(loan_Amount))

print("********************************")

#Part 2: Finding total number of Monthly payments from the List displayed 

print("Enter the length of your loan... \n\t1: 3 years\n\t2: 4 years\n\t3: 5 years\n\t4: 6 years")

percent_down = float((total_dpayment/new_vehicle_price)*100)
#print(percent_down)
option = input("Select an option: ")

if option == "1":
    llength_m = 3*12
    year=3
    
elif option =="2":
    llength_m = 4*12
    year=2
    
elif option =="4":
    llength_m =6*12
    year=4
else:
    llength_m =5*12
    year=5

print("You selected a "+str(year)+" year loan with a total of "+str(llength_m)+" monthly payments.")

    
print("********************************")
    
#Part 3: Picking up Interest Rates from the percent down and option choosen by the user above
if option=="1":
    year=3
    if percent_down < 20:
        iRate=4.00
    else:
        iRate=3.70
elif option=="2":
    year=4
    if percent_down < 20:
        iRate=4.33
    else:
        iRate=3.80
elif option=="4":
    year=3
    if percent_down < 20:
        iRate=5.00
    else:
        iRate=4.00
else:
    year=5
    if percent_down < 20:
        iRate=4.66
    else:
        iRate=3.90

print("With "+str(percent_down) +" down and a "+str(year)+" year loan, we can offer you an interest rate of "+str(iRate)+"%")

print("********************************")


#Part 4: Monthly Payment Calculation and Displaying it

monthly_interest = (iRate/1200)
#print(monthly_interest)
denominator_calc=(1+monthly_interest)**-llength_m
#print(denominator_calc)
monthly_payment= loan_Amount*(monthly_interest/(1-denominator_calc))
#print(monthly_payment)

print("Your estimated monthly payment would be $"+ str(monthly_payment) +" a month.")


    

        

    







# In[ ]:




