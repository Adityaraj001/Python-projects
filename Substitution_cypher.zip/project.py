#!/usr/bin/env python
# coding: utf-8

# In[2]:


#'''
#Adityaraj jain
#jainaditya12341@gmail.com
#project 03

#'''



substitution_cypher="EHTGDBWIUQRXLMVFSJCPYZKAON"
option="1"
while option=="1" or option=="2":
    option=input("Select an option: \n1. Encrypt a message\n2. Decrypt a\nmessage ?. Quit\n")
    
    # Encryption of the message
    if option=="1":
        secret_message=""
        z=input("Enter a message to encrypt: ")
        for x in range(0,len(z)):
            
            # Encrypt capitalized user input
            if ord(z[x])>=65 and ord(z[x])<=90:
                temp=ord(z[x])-65
                b=substitution_cypher[ord(z[x])-65]
                #print(z[x] +"\t " +str(ord(z[x]))+"\t " +str(temp)+"\t "+str(b) )
                
            # Encrypt Lower Case user input
            elif ord(z[x])>=97 and ord(z[x])<=122:
                temp=ord(z[x])-97
                b=substitution_cypher[ord(z[x])-97].lower()
                #print(z[x] +"\t " +str(ord(z[x]))+"\t " +str(temp)+"\t "+str(b.lower()) )
                
            # Encrypt any other characters (spaces, punctuation, numbers)
            else:
                b=z[x]
                #print(b +"\t " +str(ord(z[x]))+"\t " +str(ord(z[x]))+"\t "+b )
                
            # Concatenation of the User input into Secret message stored in a variable
            secret_message+=b
            
        print("The secret message is: " +secret_message+"\n")
        
    
    # Decryption of the message    
    elif option=="2":
        secret_message=""
        z=input("Enter a message to decrypt: ")
        
        for x in range(0,len(z)):
            
            # Decrypt capitalized input
                if ord(z[x])>=65 and ord(z[x])<=90:
                    for y in range(0,len(substitution_cypher)):
                        if z[x]==substitution_cypher[y]:
                            temp_var=y
                            temp=y+65
                            b=chr(y+65)
                            #print(z[x] +"\t " +str(ord(z[x]))+"\t"+str(y)+"\t"+str(temp)+"\t"+b)
                            
            # Decrypt Lower Case user input
                elif ord(z[x])>=97 and ord(z[x])<=122:
                    for y in range(0,len(substitution_cypher)):
                        if z[x].lower()==substitution_cypher[y].lower():
                            temp_var=y
                            temp=y+97
                            b=chr(y+97)
                            #print(z[x] +"\t " +str(ord(z[x]))+"\t"+str(y)+"\t"+str(temp)+"\t"+b.lower())
                            
            # Decrypt any other characters (spaces, punctuation, numbers)
                else:
                    b=z[x]
                    #print(b +"\t " +str(ord(z[x]))+"\t"+str(temp_var)+"\t"+str(ord(z[x]))+"\t"+b )
                    
            # Concatenation of the User input into Secret message stored in a variable
                secret_message+=b
        print("The secret message is: " +secret_message+"\n")
        
    #Exit from the Message cypher 
    else:
            print("Goodbye!")


# In[ ]:




