#!/usr/bin/env python
# coding: utf-8

# In[2]:


#Adityaraj
#jainaditya12341@gmail.com


name = input("hello, whose BMI shall i calculate? ")

print("Okay first I need "+ name.title() +"'s height. I'll take it in feet and inches.")
height = int(input("Feet first... "))
inch = int(input("now inches... "))


print("Thanks. Now I need "+ name.title() +"'s weight in pounds.")
weight = float(input("Please enter "+ name.title() +"'s weight... "))

#total height in inches
height_inches = inch + (height*12)
#print(height_inches)

#height in meter converted from inches
height_meter = float(height_inches/39.3701)
#print(height_meter)

#weight in kg converted from pounds
weight_kg = float(weight/2.20462)
#print(weight_Kg)

#BMI of the person
BMI = float(weight_kg/(height_meter*height_meter))
#print(BMI)

print(""+ name.title() +"'s BMI is %f." %BMI)








# In[ ]:





# In[ ]:




