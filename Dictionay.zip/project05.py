#!/usr/bin/env python
# coding: utf-8

# In[1]:


#  Adityaraj jain
# jainaditya12341@gmail.com
# Homework05



total_days={'January':31,'February':28,'March':31,'April':30,'May':31,'June':30,'July':31,'August':31,'September':30,'October':31,'November':30,'December':31}

calendar={}
for i in total_days:
    total_empty_strings=[]
    for j in range(total_days[i]):
        total_empty_strings.append("")
    calendar[i]= total_empty_strings 
#print(calendar)

which_month=""
which_day=""


day="1"
while day !="0":
        x= input("Enter a date for a holiday (for example ""July 1""):")
        count=0
    
        if x!="":
                for i in range(0,len(x)):
                    if x[i]==" ":
                        count=count+1
                
                                
                if count>= 2:
                    print("I don't see a good input there!")
                     # Message displayed to the user for wrong Input
                elif count==1:
                            which_month,which_day=x.split()
                            if which_month != "" and which_day != "":
                                        #Converting first letter to capital
                                        for i in range(len(which_month)):
                                                if i == 0:
                                                    temp_month = which_month[0].upper()
                                                else:
                                                    temp_month += which_month[i]
                                        which_month=temp_month

                                        # if user enters value with no spaces
                                        if which_month == '' or which_day == '':
                                            print("I don't see a good input there!")

                                       # if the month is wrong
                                        elif which_month not in total_days and ' ' not in which_month:
                                            print("I don't know about the month \""+which_month+"\"")


                                        # if the day is longer than expected 
                                        elif ' ' in which_day:
                                            print("I don't see a good input there!")
                                            # removing space from date as it causes errors ahead
                                            for d in range(0,len(which_day)):
                                                if which_day[d] == ' ':
                                                    b= d
                                                    temp = ''
                                                    for c in range(b):
                                                        temp += which_day[c]
                                            which_day = temp


                                        # if the date is wrong
                                        elif not (int(which_day)>=1 and int(which_day)<=total_days[which_month]):
                                            print("That month only has "+str(total_days[which_month])+" days!")


                                        # if the input is correct asking for the event
                                        else:
                                            event= input("what happens on {}, {}".format(which_month ,which_day))                     

                                            for i in calendar:
                                                if i == which_month:
                                                    for j in range(0,len(calendar[i])):
                                                        if j == int(which_day) - 1:
                                                            calendar[i][j]= event
                                                            break
                else:
                    print("I don't see a good input there!")
                    
#displaying the events of Calendar
        elif x=="":
            for i in calendar:
                for k in range(0,len(calendar[i])):
                    if calendar[i][k] != '':
                        print("\n"+i+" "+str(k+1)+" : "+calendar[i][k])
                        print("\nGoodbye!")
            break

    
                


# In[ ]:





# In[ ]:




